Please install(if not existing) the following packages:

pip install langchain

pip install langchain-openai

pip install -qU langchain-core langchain-mistralai